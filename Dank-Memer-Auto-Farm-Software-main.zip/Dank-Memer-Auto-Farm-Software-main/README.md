# Dank-Memer-Auto-Farm-Software
This is a Python program that will automate Dank Memer commands for you. You can leave it on while you're afk and it will automatically earn you a ton of coins.
Note: To run it you must have Python installed with Python path variables enabled.
Tutorial Video: https://youtu.be/G8mffzYCC3w
